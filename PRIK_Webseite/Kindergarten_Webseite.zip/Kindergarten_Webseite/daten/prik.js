// Daten Kindergarten (PRiK) — wird von index.html geladen.
// Hier steht der Inhalt (Gruppen, Einheiten, Material, Fotos).
// Aufbau/Aussehen der Seite: index.html. Schritt-für-Schritt-Hilfe: siehe ANLEITUNG (PDF).

klassen.PRiK = ['Gruppe 1', 'Gruppe 2'];

// ---------------------------------------------------------------------------
// BEISPIEL (zum Kopieren — die Zeilen mit // davor löschen, dann ist es aktiv):
//
// unitsData.PRiK = {
//   'Gruppe 1': [
//     {t:'1. Einheit: Titel der Einheit', p:12, mat:[
//       {label:'Handpuppe', photo:'k1-handpuppe.jpg'},        // Material in der Kiste, mit Foto
//       {label:'Sitzkissen'},                                  // Material in der Kiste, ohne Foto
//       {label:'Papier & Stifte', bring:true},                 // selbst mitbringen
//     ]},
//     {t:'2. Einheit: Titel', p:14, noMaterial:true},          // Einheit ohne Material
//   ],
//   'Gruppe 2': [
//   ],
// };
// ---------------------------------------------------------------------------
